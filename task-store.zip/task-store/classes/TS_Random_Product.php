<?php

namespace SG_Task_Store;

use WP_Query;

// Adds a random product box after the single post's content


class TS_Random_Product {

    public function __construct() {
        // Hook into 'the_content' filter
        add_filter('the_content', array($this, 'append_random_product_to_content'));

        // add the styling
        add_action('wp_enqueue_scripts', array($this, 'ts_enqueue_random_product_styles'));
    }

    // Method to query a random product
    public function get_random_product() {
        // Query for a random product
        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => 1,
            'orderby'        => 'rand',
        );
        $random_product_query = new WP_Query($args);

        // Check if we have any products
        if ($random_product_query->have_posts()) {
            while ($random_product_query->have_posts()) {
                $random_product_query->the_post();
                $product_title = get_the_title();
                $product_link = get_permalink();
                
                // Generate the HTML
                $output = '<div class="random-product">';
                $output .= '<h2>Random Product</h2>';
                $output .= '<p><a href="' . esc_url($product_link) . '">' . esc_html($product_title) . '</a></p>';
                $output .= '</div>';
            }
            // Reset post data
            wp_reset_postdata();
        } else {
            // If no products found, return empty string
            $output = '';
        }

        return $output;
    }

    // Method to append the random product to content
    public function append_random_product_to_content($content) {
        // Only add it to a single post
        if (is_singular('post') && is_main_query()) {
            // Get the random product HTML
            $random_product_html = $this->get_random_product();
            
            // Append the random product HTML to the content
            $content .= $random_product_html;
        }

        return $content;
    }


    // include the styling
    function ts_enqueue_random_product_styles() {
        wp_enqueue_style('random-product-css', TASK_STORE_URL . '/css/random-product.css', array(), '1.0', 'all');
    }



} // end of class

// Initialise the class
new TS_Random_Product;

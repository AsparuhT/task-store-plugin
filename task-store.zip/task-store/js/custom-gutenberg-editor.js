document.addEventListener('DOMContentLoaded', function() {


    const { createElement, useState, useEffect } = wp.element;
    const { render } = wp.element;
    const { BlockEditorProvider, WritingFlow, ObserveTyping, BlockList } = wp.blockEditor;
    const { registerCoreBlocks } = wp.blockLibrary;
    const { parse } = wp.blocks;

    // Register core blocks
    registerCoreBlocks();

    const EditorComponent = () => {
        const [blocks, setBlocks] = useState([]);
        const [settings, setSettings] = useState({});

        useEffect(() => {
            // Initialize blocks
            const rawContent = '<!-- wp:paragraph --><p>This is as far as I could go rendering Gutenber and its sidebar, so I falled back to the classic editor. I could not find any relevant documentation on how its done, what am I missing?</p><!-- /wp:paragraph -->';
            try {
                const initialBlocks = parse(rawContent);
                console.log("Parsed initial blocks:", initialBlocks); // Debugging log
                setBlocks(initialBlocks);
            } catch (error) {
                console.error("Error parsing initial blocks:", error);
            }
        }, []);

        const handleInputChange = (newBlocks) => {
            console.log("New blocks on input change:", newBlocks); // Debugging log
            setBlocks(newBlocks);
        };

        const handleChange = (newBlocks) => {
            console.log("New blocks on change:", newBlocks); // Debugging log
            setBlocks(newBlocks);
        };

        if (!blocks || !Array.isArray(blocks)) {
            console.error("Blocks is not an array:", blocks); // Debugging log
            return null;
        }

        return createElement(
            BlockEditorProvider,
            {
                value: blocks,
                onInput: handleInputChange,
                onChange: handleChange,
                settings,
            },
            createElement('div', { className: 'editor-wrapper' },
                createElement(WritingFlow, null,
                    createElement(BlockList, null)
                ),
                createElement(ObserveTyping, null)
            )
        );
    };

    // Render the Gutenberg editor in the specified div
    render(
        createElement(EditorComponent),
        document.getElementById('editor-root')
    );
});

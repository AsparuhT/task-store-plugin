<?php

namespace SG_Task_Store;

// the main plugin class

class Task_Store
{

    function __construct()
    {

        // Add the Store page and submenu
        add_action('admin_menu', array($this, 'add_store_pages'));

        // Also check for the 'product' post type and add it if necessary
        add_action('init', array($this, 'register_product_post_type'));

        // add the 'ts-product' meta box
        add_action('add_meta_boxes', array($this, 'add_custom_ts_product_metabox'));

        // save the metaboxes on 'save_post'
        add_action('save_post', array($this, 'ts_save_product_meta_box_data'));

        // try to enqueue Gutenberg
        add_action('admin_enqueue_scripts', array($this, 'enqueue_custom_gutenberg_assets'));
    } // end of construct




    /***  Add the Store page and submenu  ***/

    function add_store_pages()
    {
        // add the main admin page
        add_menu_page(
            'Task Store',                       // Page title (shown in the browser)
            'Store',                            // Menu title
            'manage_options',                   // Capability
            'task-store',                       // Menu slug
            array($this, 'all_products_menu_html'),     // Function to display the page content
            'dashicons-store',                  // Dashicons class
            25                                  // Position in the menu
        );



        // Add submenu page for the pourpose of chaning the name of the first default menu name
        add_submenu_page(
            'task-store',                   // Parent slug 
            'Task Store',                   // Page title
            'Home',                         // Replacing the default Store with Home menu name
            'manage_options',               // Capability
            'task-store',                   // Has to be the same as the slug of the parent
            array($this, 'all_products_menu_html')  // Has to add the same html
        );




        // add new product with the classic editor  instead of Gutenberg
        add_submenu_page(
            'task-store',                   // Parent slug
            'Task Store',                   // Page title
            'Add New Product',              // Menu title
            'manage_options',               // Capability
            'task-store-classic-editor',    // Menu slug
            array($this, 'add_classic_editor_page')   // Function
        );



        // add new product
        add_submenu_page(
            'task-store',                   // Parent slug
            'Task Store',                   // Page title
            'Gutenberg editor',              // Menu title
            'manage_options',               // Capability
            'custom-gutenberg-editor',          // Menu slug
            array($this, 'render_custom_gutenberg_editor')   // Function
        );
    } // end of add_store_pages()




    /*** Main Menu  ***/

    // Template for listing the products
    function all_products_menu_html()
    {
        require TASK_STORE_PATH . '/template-parts/all_products.php';
    }








    /*** Resgistere 'prodcut' post-type  ***/

    // Check if the 'preduct' post type is registered already and if not, add it
    function register_product_post_type()
    {
        if (!post_type_exists('product')) {

            register_post_type('product', array(
                'label' => 'Products',
                'public' => true,
                'show_in_rest' => true,
                'publicly_queryable' => true,
                'show_in_menu' => false, // hide the Products post type
                'query_var' => true,
                'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
                'has_archive' => true,
                // create the required URL stucture
                'rewrite' => array('slug' => 'product', 'with_front' => false),
                'menu_icon' => 'dashicons-products'
            ));

            // flush the rewrite rules after the post-type is created
            flush_rewrite_rules();
        }
    } // end of register_product_post_type









    /*** Attempt to render Gutennberg  ***/

    function enqueue_custom_gutenberg_assets($hook_suffix)
    {
        //echo $hook_suffix;
        if ($hook_suffix === 'store_page_custom-gutenberg-editor') {
            wp_enqueue_script('wp-edit-post'); // Includes necessary Gutenberg scripts
            wp_enqueue_script('wp-editor');
            wp_enqueue_script('wp-blocks');
            wp_enqueue_script('wp-i18n');
            wp_enqueue_script('wp-element');
            wp_enqueue_script('wp-components');
            wp_enqueue_script('wp-data');
            wp_enqueue_script(
                'custom-gutenberg-editor',
                TASK_STORE_URL . '/js/custom-gutenberg-editor.js',
                array('wp-edit-post', 'wp-editor', 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-data'),
                null,
                true
            );

            wp_enqueue_style(
                'custom-gutenberg-style',
                TASK_STORE_URL . '/css/custom-gutenberg-editor.css',
                array('wp-edit-blocks')
            );

            // Localize the script to pass data to the gutenber js
            wp_localize_script('custom-gutenberg-editor', 'customGutenbergEditorData', array(
                'post' => array(
                    'id' => 'task-store-editor',
                    'title' => 'My Custom Post',
                    'content' => 'Content goes here...',
                    'type' => 'product', // Ensure the post type is set to a valid post type
                    'status' => 'draft',
                ),
                'settings' => array(
                    // additional data here
                ),
            ));
        } // end if check

    } // end enqueue_custom_gutenberg_assets




    // render gutenberg 
    function render_custom_gutenberg_editor()
    {
?>
        <div class="wrap">
            <h1><?php _e('Custom Gutenberg Editor', 'textdomain'); ?></h1>
            <div id="editor-root"></div>
        </div>
<?php
    }



    /*** End of Trying to include the Gutenber editor */










    /*** Add the Classic editor  ***/

    // add the classic editor
    function add_classic_editor_page()
    {
        global $post, $post_type, $current_screen, $is_IE, $title;

        // Check if we have post ID to enable edits
        if (isset($_GET['post'])) {
            $post_id = intval($_GET['post']);
            $post = get_post($post_id);
        } else {
            // if not post ID, then create new post
            $post = get_default_post_to_edit('product', true);
        }
        setup_postdata($post);



        // Set the global $post_type to 'product'.
        $post_type = 'product';

        // Simulate loading the post editing screen.
        require_once ABSPATH . 'wp-admin/admin-header.php';

        // Set up the $current_screen global. This adds the sidebar with the publish button
        $current_screen = convert_to_screen('product');
        $current_screen->post_type = $post_type;
        $current_screen->id = 'product';
        set_current_screen($current_screen);

        // Define the missing variables.
        $is_IE = false;
        $title = '';

        // Include the actual post editor template.
        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">Add New Product</h1>';
        include ABSPATH . 'wp-admin/edit-form-advanced.php';
        echo '</div>';

        // Reset post data.
        wp_reset_postdata();
    }








    /*
        add_meta_box(
            1, // The ID, or the unique identifier for the meta box.
            2, // Title. We can wrap it in the  __() localisation function for translation.
            3, // Callback function that will be called to render the content of the meta box.
            4, // The post type to which this meta box should be added
            5, // The context (or location) where the meta box should appear
            6  // Priority. We can use 'default', 'high' etc.
        );
*/

    // Add the Price and Quantity metabox for ts-proruct
    function add_custom_ts_product_metabox()
    {
        // Only show then in my custom editor
        if (isset($_GET['page']) && $_GET['page'] === 'task-store-classic-editor') {
            add_meta_box(
                'ts-product_meta_box', // The ID
                'TS Product Details', // Title
                array($this, 'render_ts_product_meta_box_content'), // Callback
                'product', // For post-type
                'side', // The context / location
                'high'  // Priority
            );
        } // end if check for custom editor
    } // end of add_custom_ts_product_metabox


    // The callback to render the the Price and Quantity metabox
    function render_ts_product_meta_box_content($post)
    {
        // Add the nonce
        wp_nonce_field('ts_product_nonce_action', 'ts_product_nonce');

        // Get existing values from the database
        $price = get_post_meta($post->ID, '_ts_product_price', true);
        $quantity = get_post_meta($post->ID, '_ts_product_quantity', true);


        // Display the form fields
        echo '<label for="ts_product_price">Price</label>';
        echo '<input type="number" step="0.01" id="ts_product_price" name="ts_product_price" value="' . esc_attr($price) . '" size="15" style="display:block;/>';

        echo '<label for="ts_product_quantity">Quantity</label>';
        echo '<input type="number" id="ts_product_quantity" name="ts_product_quantity" value="' . esc_attr($quantity) . '" size="15" min="0" step="1" style="display:block; />';
    }


    // Validate and save the custom fields data when the post is saved
    function ts_save_product_meta_box_data($post_id)
    {
        // Check if the nonce is set.
        if (!isset($_POST['ts_product_nonce'])) {
            return $post_id;
        }

        // Verify that the nonce is valid.
        if (!wp_verify_nonce($_POST['ts_product_nonce'], 'ts_product_nonce_action')) {
            return $post_id;
        }

        // If this is an autosave, our form has not been submitted, don't do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }

        // Check the user's permissions.
        if (isset($_POST['post_type']) && 'product' == $_POST['post_type']) {
            if (!current_user_can('edit_post', $post_id)) {
                return $post_id;
            }
        }

        // Sanitize user input.
        $price = isset($_POST['ts_product_price']) ? sanitize_text_field($_POST['ts_product_price']) : 0;
        $quantity = isset($_POST['ts_product_quantity']) ? intval($_POST['ts_product_quantity']) : 0;

        // Update the meta fields in the database.
        update_post_meta($post_id, '_ts_product_price', $price);
        update_post_meta($post_id, '_ts_product_quantity', $quantity);


        // redirect to my store after Publish or Update
        wp_redirect(admin_url('admin.php?page=task-store'));
        exit;
    } // end of render_ts_product_meta_box_content()







} // end of class Task_Store
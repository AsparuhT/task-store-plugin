<?php

if (isset($_GET['page']) && $_GET['page'] === 'task-store') {

    // Query for products
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => -1,
    );
    $product_query = new WP_Query($args);
}

?>

<div class="wrap">
    <h1 class="wp-heading-inline">Task Store Products</h1>

    <!-- Add New Product button -->
    <a href="<?php echo admin_url('admin.php?page=task-store-classic-editor'); ?>" class="page-title-action">Add New Product</a>

    <hr class="wp-header-end">
    <table class="wp-list-table widefat fixed striped table-view-list">
        <thead>
            <tr>
                <th scope="col" id="title" class="manage-column column-title column-primary">Title</th>
                <th scope="col" id="price" class="manage-column column-price">Price</th>
                <th scope="col" id="quantity" class="manage-column column-quantity">Quantity</th>
                <th scope="col" id="date" class="manage-column column-date">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($product_query->have_posts()) {
                while ($product_query->have_posts()) {
                    $product_query->the_post();
                    $price = get_post_meta(get_the_ID(), '_ts_product_price', true);
                    $quantity = get_post_meta(get_the_ID(), '_ts_product_quantity', true);
                    // add a redirect to my custom builder for edits
                    $edit_url = admin_url('admin.php?page=task-store-classic-editor&post=' . get_the_ID());
            ?>
                    <tr>
                        <td class="title column-title has-row-actions column-primary">
                            <strong><a class="row-title" href="<?php echo esc_url($edit_url); ?>"><?php the_title(); ?></a></strong>
                            <div class="row-actions">

                                <!-- the edit -->
                                <span class="edit"><a href="<?php echo esc_url($edit_url); ?>" class="submitdelete">Edit</a></span>

                                <!-- the tash -->
                                <span class="trash"><a href="<?php echo get_delete_post_link(get_the_ID()); ?>" class="submitdelete">Trash</a></span>

                                <!-- the view -->
                                <span class="view"><a href="<?php echo get_permalink(get_the_ID()); ?>" target="_blank">View</a></span>
                            </div>
                        </td>
                        <td class="price column-price"><?php echo esc_html($price); ?></td>
                        <td class="quantity column-quantity"><?php echo esc_html($quantity); ?></td>
                        <td class="date column-date"><?php echo get_the_date(); ?></td>
                    </tr>
                <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="4">No products found.</td>
                </tr>
            <?php
            }
            wp_reset_postdata();
            ?>
        </tbody>
        <tfoot>
            <tr>
                <th scope="col" class="manage-column column-title column-primary">Title</th>
                <th scope="col" class="manage-column column-price">Price</th>
                <th scope="col" class="manage-column column-quantity">Quantity</th>
                <th scope="col" class="manage-column column-date">Date</th>
            </tr>
        </tfoot>
    </table>
</div>
<?php
/*
 * Plugin Name: Task Store
 * Description: Junor WordPress Dev task.
 * Version: 1.0
 * Author: Asparuh Tenev
 * Author URI: https://atenev.com
 */

namespace SG_Task_Store;


// Exit if accessed directly
if (!defined('ABSPATH')) {
    echo "The plugin can't be accessed directly";
    exit;
}

// Define the plugin paths
define('TASK_STORE_PATH', plugin_dir_path(__FILE__));
define('TASK_STORE_URL', plugin_dir_url(__FILE__));

// Bonus task one
require_once 'classes/TS_Random_Product.php';

// Bonus task two
require_once 'classes/TS_REST_API.php';

// The main plugin class
require_once 'classes/Task_Store.php';
 


// Initialise the plugin
function task_store_init()
{
    new Task_Store;
}
add_action('plugins_loaded', 'SG_Task_Store\task_store_init');

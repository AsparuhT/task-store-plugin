<?php

namespace SG_Task_Store;

use WP_Query;

// RETS URL - /wp-json/ts/v1/products


class TS_REST_API {
    public function __construct() {
        // Hook to register the REST API routes
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    // Register the REST routes
    public function register_routes() {
        register_rest_route('ts/v1', '/products', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_all_products'),
            'permission_callback' => '__return_true', // Makes the endpoint public
        ));
    }


    // Handle the request and return all products
    public function get_all_products() {

        // Query for products
        $args = array(
            'post_type' => 'product'
        );
        $query = new WP_Query($args);

        // Check if any products were found
        if (!$query->have_posts()) {
            // send a 404 staus code and a message if no products are found
            wp_send_json_error(array('message' => 'No products found'), 404);
        }

        // Prepare the products data
        $products = array();
        while ($query->have_posts()) {
            $query->the_post();
            $product_data = array(
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'link' => get_permalink(),
                'price' => get_post_meta(get_the_ID(), '_ts_product_price', true),
                'quantity' => get_post_meta(get_the_ID(), '_ts_product_quantity', true),
            );
            // Add the data into the array
            $products[] = $product_data;
        }

        // Reset post data
        wp_reset_postdata();

        // Return the products data with pagination info
        wp_send_json_success($products);
    }
}

// Initialise the class
new TS_REST_API;
